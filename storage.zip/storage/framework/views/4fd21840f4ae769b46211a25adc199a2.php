<?php $__env->startSection('content'); ?>
<?php if(auth()->user()->role == "admin"): ?>
<div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
    <div class="tile-stats">
        <div class="icon"><i class="fa fa-asterisk"></i>
        </div>
        <div class="count">10</div>

        <h3>Total Product</h3>
    </div>
</div>
<div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
    <div class="tile-stats">
        <div class="icon"><i class="fa fa-users"></i>
        </div>
        <div class="count">10</div>

        <h3>Total Customer</h3>
    </div>
</div>
<div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
    <div class="tile-stats">
        <div class="icon"><i class="fa fa-files-o"></i>
        </div>
        <div class="count">2</div>

        <h3>Total Transaksi</h3>
    </div>
</div>
<?php else: ?>
<div>
    Dashboard for <?php echo e(auth()->user()->role); ?>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\primasambara\resources\views/home.blade.php ENDPATH**/ ?>